package Concurrent;

import java.util.List;
import java.util.Map;

/**
 * Clase MonitorConsola: Controla el acceso concurrente a la consola.
 */

// Clase que sincroniza el acceso concurrente a la consola.
public class MonitorConsola {

    // Imprime un mensaje en consola de forma segura.
    public synchronized void print(String message) {
        System.out.println(message);
    }

    // Imprime un mensaje formateado de forma segura.
    public synchronized void printf(String format, Object... args) {
        System.out.printf(format, args);
    }

    // Imprime un mapa con listas de valores de forma segura.
    public synchronized void printmap(Map<String, List<String>> mapa) {
        for (String clave : mapa.keySet()) {
            List<String> valores = mapa.get(clave);
            if (valores != null && !valores.isEmpty()) {
                System.out.print(clave + " - ");
                for (int i = 0; i < valores.size(); i++) {
                    System.out.print(valores.get(i));
                    if (i < valores.size() - 1) {
                        System.out.print(", ");
                    }
                }
                System.out.println();
            } else {
                System.out.println(clave + " - (Sin valores)");
            }
        }
    }
}

