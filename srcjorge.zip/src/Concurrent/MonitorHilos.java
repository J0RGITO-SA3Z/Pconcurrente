package Concurrent;
/**
 * Clase MonitorHilos: Controla el acceso concurrente al Array de hilos OyenteCliente activos.
 */
public class MonitorHilos {
    private final Thread[] listaHilos;
    private int numHilos;

    public MonitorHilos(int capacidadMaxima) {
        this.listaHilos = new Thread[capacidadMaxima];
        this.numHilos = 0;
    }


    // Añade un hilo al monitor de forma segura.
    public synchronized void agregarHilo(Thread hilo) {
        for (int i = 0; i < listaHilos.length; i++) {
            if (listaHilos[i] == null || !listaHilos[i].isAlive()) {
                listaHilos[i] = hilo;
                numHilos++;
                System.out.println("Hilo agregado. Total hilos activos: " + numHilos);
                break;
            }
        }
    }


    // Elimina un hilo del monitor cuando termina su ejecución.
    private synchronized void eliminarHilo(Thread hilo) {
        for (int i = 0; i < listaHilos.length; i++) {
            if (listaHilos[i] == hilo) {
                listaHilos[i] = null;
                numHilos--;
                System.out.println("Hilo eliminado. Total hilos activos: " + numHilos);
                break;
            }
        }
    }


     // Espera a que todos los hilos terminen (por ejemplo, al cerrar el servidor).
    public synchronized void esperarTodos() {
        System.out.println("Esperando a que terminen todos los hilos...");
        for (Thread hilo : listaHilos) {
            if (hilo != null && hilo.isAlive()) {
                try {
                    hilo.join(500); // timeout opcional
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.err.println("Interrupción al hacer join en un hilo.");
                }
            }
        }
        System.out.println("Todos los hilos han terminado.");
    }


    // Metodo para registrar que un hilo ha terminado.
    public void registroTerminacion(Thread hilo) {
        eliminarHilo(hilo);
    }

}