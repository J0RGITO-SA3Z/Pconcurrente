package Server;

import Common.*;
import Concurrent.*;
import View.ServidorVista;
import java.io.*;
import java.util.*;
import java.net.*;


public class OyenteCliente implements Runnable {
    private final Socket socketCliente;
    private String nombre_cliente;
    private final ServidorVista vista;
    private final BufferPuertos buffer_puertos;
    private final Map<String, IP_puerto> usuarios; // Mapa compartido
    private final Map<String, List<String>> informacion;
    private final Stack<Integer> idsDisponibles;
    private Entero num_usuarios_conectados = new Entero();
    private final Locks lock_map_usuarios;
    private final Locks lock_map_informacion;
    private final Locks lock_num_usuarios;
    private final Locks lock_id;
    private int id_usuario;
    private final Entero num_ids;
    private final ObjectOutputStream salida;
    private final ObjectInputStream entrada;
    private boolean ejecutando;
    private final int limite_usuarios;
    private int puerto_asignado;

    public OyenteCliente(Socket socketCliente, Map<String, IP_puerto> usuarios, Map<String, List<String>> informacion, Entero num_ids, ServidorVista vista, Locks lock_map_usuarios,
                         Locks lock_num_usuarios, Locks lock_informacion, Locks lock_id, BufferPuertos buffer_puertos, Entero num_usuarios_conectados, Stack<Integer> idsDisponibles, int limite_usuarios) {
        try {
            salida = new ObjectOutputStream(socketCliente.getOutputStream());
            salida.flush();
            entrada = new ObjectInputStream(socketCliente.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.nombre_cliente = null;
        this.socketCliente = socketCliente;
        this.vista = vista;
        this.usuarios = usuarios;
        this.lock_map_usuarios = lock_map_usuarios;
        this.lock_num_usuarios = lock_num_usuarios;
        this.lock_map_informacion = lock_informacion;
        this.lock_id = lock_id;
        this.idsDisponibles = idsDisponibles;
        this.id_usuario = -1;
        this.num_ids = num_ids;
        this.informacion = informacion;
        this.buffer_puertos = buffer_puertos;
        this.num_usuarios_conectados = num_usuarios_conectados;
        this.ejecutando = true;
        this.limite_usuarios = limite_usuarios;
    }


    private void cerrarRecursos() {
        try {
            if(nombre_cliente == null){
                // Borramos la lista de archivos del usuario
                lock_map_informacion.takeLock(id_usuario);
                this.informacion.remove(nombre_cliente);
                lock_map_informacion.releaseLock(id_usuario);
                // Borramos el usuario de la lista de usuarios conectados
                lock_map_usuarios.takeLock(id_usuario);
                this.usuarios.remove(nombre_cliente);
                lock_map_usuarios.releaseLock(id_usuario);
                // Liberamos el id del usuario
                if (id_usuario >= 0) {
                    lock_id.takeLock(0);
                    liberarId(id_usuario);
                    lock_id.releaseLock(0);
                }
                // Decrementamos la variable de usuarios conectados
                lock_num_usuarios.takeLock(id_usuario);
                this.num_usuarios_conectados.decrement();
                lock_num_usuarios.releaseLock(id_usuario);
            }

            ejecutando = false; // Detener el bucle
            if (entrada != null) entrada.close();
            if (salida != null) salida.close();
            if (socketCliente != null) socketCliente.close();
            Servidor.getMonitorHilos().registroTerminacion(Thread.currentThread());
        } catch (IOException e) {
            vista.error_cerrar_recursos(e.getMessage());
        }
    }

    private void enviarListaInformacion(){
        lock_map_informacion.takeLock(id_usuario);
        Map<String, List<String>> copia = new HashMap<String, List<String>>(informacion);
        lock_map_informacion.releaseLock(id_usuario);
        MensajeLista mensajeLista = new MensajeLista(copia);
        try {
            salida.writeObject(mensajeLista);
            salida.flush();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Funcion que asigna un id a los nuevos usuarios
    public int asignarId() {
        if (!idsDisponibles.isEmpty()) {
            // Reutiliza un ID disponible del pool
            return idsDisponibles.pop();
        } else if (num_ids.getNum() < limite_usuarios) {
            // Asigna un nuevo ID si no se ha alcanzado el límite
            num_ids.increment();
            return num_ids.getNum() - 1;
        } else {
            throw new IllegalStateException("Límite máximo de usuarios alcanzado.");
        }
    }

    // Funcion que  libera los ids de los usuarios que se desconectan
    public void liberarId(int id) {
        if (id >= 0 && id < num_ids.getNum()) {
            idsDisponibles.push(id); // Añade el ID al pool
            System.out.println("ID liberado: " + id);
        } else {
            throw new IllegalArgumentException("ID inválido: " + id);
        }
    }

    @Override
    public void run() {
        try {
            while (ejecutando) {
                // Leer mensaje del cliente
                Mensaje mensaje = (Mensaje) entrada.readObject();
                vista.mensajeRecibido(mensaje.getTipo().toString());
                switch (mensaje.getTipo()) {
                    case CONEXION:
                        MensajeConexion conexion = (MensajeConexion) mensaje;
                        gestionarConexion(conexion);
                        break;
                    case ERROR_PUERTO_P2P_NO_DISPONIBLE:
                        gestionarErrorPuertoP2PNoDisponible();
                        break;
                    case ACTUALIZAR_INFORMACION_CLIENTE:
                        MensajeInformacionCiente informacionCiente = (MensajeInformacionCiente) mensaje;
                        gestionarActualizarInformacionCliente(informacionCiente);
                        break;
                    case SOLICITUD_LISTA:
                        MensajeSolicitudLista solicitudLista = (MensajeSolicitudLista) mensaje;
                        vista.listaInformacionSolicitada();
                        enviarListaInformacion();
                        break;
                    case PEDIR_PRODUCTO:
                        MensajePedirProd descarga = (MensajePedirProd) mensaje;
                        gestionarSolicitudDescarga(descarga);
                        break;
                    case CERRAR_SESION:
                        MensajeCerrarSesion cierre = (MensajeCerrarSesion) mensaje;

                        lock_map_usuarios.takeLock(id_usuario);
                        this.usuarios.remove(nombre_cliente);
                        lock_map_usuarios.releaseLock(id_usuario);

                        lock_num_usuarios.takeLock(id_usuario);
                        this.num_usuarios_conectados.decrement();
                        lock_num_usuarios.releaseLock(id_usuario);

                        lock_map_informacion.takeLock(id_usuario);
                        this.informacion.remove(nombre_cliente);
                        lock_map_informacion.releaseLock(id_usuario);

                        if (id_usuario >= 0) {
                            lock_id.takeLock(0);// el 0 es para la interfaz pero no lo usa
                            liberarId(id_usuario);
                            lock_id.releaseLock(0);
                        }

                        mensaje = new MensajeConfCierre();
                        salida.writeObject(mensaje);
                        salida.flush();
                        ejecutando = false;
                        vista.cierre_conexion(nombre_cliente);
                        break;

                    default:
                        vista.tipoMensajeDesconocido();
                }
            }
        } catch (EOFException | SocketException e) {
            vista.cliente_desconectado_abruptamente();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarRecursos(); // Cerrar recursos
        }
    }

    private void gestionarSolicitudDescarga(MensajePedirProd descarga) {
        try {
            // Obtener los datos del mensaje
            String propietarioArchivo = descarga.getPropietario();
            String nombreArchivo = descarga.getNombreArchivo();

            // Verificar si el propietario existe en el mapa
            lock_map_informacion.takeLock(id_usuario);
            if (!informacion.containsKey(propietarioArchivo)) {
                vista.error_descarga_usuario_no_encontrado();
                MensajeErrPropietarioNoExistente err = new MensajeErrPropietarioNoExistente();
                salida.writeObject(err);
                salida.flush();
                return;
            }
            lock_map_informacion.releaseLock(id_usuario);

            lock_map_informacion.takeLock(id_usuario);
            // Obtener la lista de archivos del propietario
            List<String> archivosPropietario = new ArrayList<>(informacion.get(propietarioArchivo));
            lock_map_informacion.releaseLock(id_usuario);

            // Verificar si el archivo solicitado existe en la lista del propietario
            if (archivosPropietario == null || !archivosPropietario.contains(nombreArchivo)) {
                vista.error_descarga_archivo_no_encontrado();
                MensajeErrArchivoInvalido err = new MensajeErrArchivoInvalido();
                salida.writeObject(err);
                salida.flush();
                return;
            }

            // Extraemos la IP y el puerto del usuario que es propietario del archivo solicitado
            this.lock_num_usuarios.takeLock(id_usuario);
            IP_puerto datos_propietario = usuarios.get(propietarioArchivo);
            this.lock_num_usuarios.releaseLock(id_usuario);

            pedirProd(propietarioArchivo, nombreArchivo);

            Mensaje infoP2P = new MensajeInfoP2P(datos_propietario.getIp(), datos_propietario.getPuerto(), nombreArchivo);
            salida.writeObject(infoP2P);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void gestionarActualizarInformacionCliente(MensajeInformacionCiente informacionCiente) {
        lock_map_informacion.takeLock(id_usuario);
        informacion.put(nombre_cliente, informacionCiente.getDatos());
        lock_map_informacion.releaseLock(id_usuario);
    }

    private void gestionarErrorPuertoP2PNoDisponible() {
        try {
            puerto_asignado = buffer_puertos.extraer();
            Mensaje nuevoPuerto = new MensajeAsignarNuevoPuerto(puerto_asignado);
            salida.writeObject(nuevoPuerto);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void gestionarConexion(MensajeConexion conexion) {
        try {
            // Asignar un puerto al cliente
            puerto_asignado = buffer_puertos.extraer();

            // Si el servidor ha alcanzado el límite de usuarios no acepta más
            lock_num_usuarios.takeLock(id_usuario);
            boolean servidor_lleno = num_usuarios_conectados.getNum() >= limite_usuarios;
            lock_num_usuarios.releaseLock(id_usuario);

            if(servidor_lleno){
                // Notificamos al cliente que el servidor está lleno
                MensajeErrServidorLleno err = new MensajeErrServidorLleno();
                salida.writeObject(err);
                salida.flush();
            }else{
                // Asignamos un id al usuario
                lock_id.takeLock(0); // este 0 es para q entre en la interfaz, pero no lo usa
                id_usuario = asignarId();
                lock_id.releaseLock(0);

                // Incrementamos el numero de usuarios conectados
                lock_num_usuarios.takeLock(id_usuario);
                num_usuarios_conectados.increment();
                lock_num_usuarios.releaseLock(id_usuario);

                // Verificamos si el nombre de usuario ya estaba en uso
                lock_map_usuarios.takeLock(id_usuario);
                boolean usuario_valido = !this.usuarios.containsKey(conexion.getNombre());
                if(usuario_valido){ this.usuarios.put(conexion.getNombre(), new IP_puerto(this.socketCliente.getInetAddress().toString(), puerto_asignado)); }
                lock_map_usuarios.releaseLock(id_usuario);

                // Notificamos al cliente que se ha conectado exitosamente o que su usuario ya existe
                if(usuario_valido){
                    vista.equipoConectado(nombre_cliente);
                    nombre_cliente = conexion.getNombre();
                    MensajeConfConexion confirmacion = new MensajeConfConexion(puerto_asignado, nombre_cliente);
                    salida.writeObject(confirmacion);
                    salida.flush();
                } else{
                    MensajeErrUsuarioExistente err = new MensajeErrUsuarioExistente();
                    salida.writeObject(err);
                    salida.flush();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void pedirProd(String propietarioArchivo, String nombreArchivo) {
        try {
            // Obtener la IP y el puerto del propietario
            IP_puerto datos_propietario = usuarios.get(propietarioArchivo);

            // Quitamos la barra de la IP si la hay
            String ip = datos_propietario.getIp().replace("/", "");

            Socket socketServerP2P = new Socket(ip, datos_propietario.getPuerto());
            ObjectOutputStream salidaServerP2P = new ObjectOutputStream(socketServerP2P.getOutputStream());
            salidaServerP2P.flush();
            ObjectInputStream entradaServerP2P = new ObjectInputStream(socketServerP2P.getInputStream());

            // Enviar petición de producto
            Mensaje mensaje = new MensajePedirProd();
            salidaServerP2P.writeObject(mensaje);
            salidaServerP2P.flush();

            // Si tanto el usuario como el archivo existen, proceder con la descarga
            vista.descarga_archivo_solicitada(nombreArchivo, propietarioArchivo);

            Mensaje preparado = (Mensaje) entradaServerP2P.readObject();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}