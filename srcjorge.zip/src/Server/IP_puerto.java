package Server;

public class IP_puerto {
    private final String ip;
    private final int puerto;

    public IP_puerto(String texto, int numero) {
        this.ip = texto;
        this.puerto = numero;
    }

    public String getIp() {
        return ip;
    }

    public int getPuerto() {
        return puerto;
    }
}
