// Client/OyenteP2P.java
package Client;

import java.io.*;
import java.net.*;

public class ServidorP2P implements Runnable {

    private volatile boolean ejecutando = true;
    private ServerSocket serverSocketP2P;
    private GestionListas gestionListas;
    private String nombreUsuario;

    public ServidorP2P(ServerSocket serverSocketP2P, GestionListas gestionListas, String nombreUsuario) {
        this.serverSocketP2P = serverSocketP2P;
        this.gestionListas = gestionListas;
        this.nombreUsuario = nombreUsuario;
    }

    public void detener() {
        ejecutando = false;
        try {
            if (serverSocketP2P != null && !serverSocketP2P.isClosed()) {
                serverSocketP2P.close(); // Esto rompe el accept()
            }
        } catch (IOException e) {
            System.err.println("Error al cerrar el servidor P2P.");
        }
    }

    @Override
    public void run() {
        try {
            while (ejecutando) {
                // Acepta al usuario que quiera conectarse
                Socket socketSolicitante = serverSocketP2P.accept();
                // Crear un nuevo hilo para manejar la descarga del cliente
                Thread hiloCliente = new Thread(new ProveedorP2P(socketSolicitante, gestionListas, nombreUsuario));
                hiloCliente.start();
            }
        } catch (IOException e) {
            if (!serverSocketP2P.isClosed()) {
                System.err.println("Error inesperado en ServidorP2P: " + e.getMessage());
            } else {
                System.out.println("Servidor P2P detenido correctamente.");
            }
        }
    }
}