package Client;


import java.io.*;
import java.net.*;
import java.util.*;
import Common.*;
import Concurrent.*;
import View.ClienteVista;
import java.util.Scanner;

public class Cliente {

    private final static int PUERTO_SERVIDOR = 5000;
    private final static int PROCESOS_C_OS_PARALELO = 2;
    private final static String IP = "localhost"; // Aqui hay que poner la IP del cliente, como estamos en local es localhost
    private final Socket socket;
    private final Locks lock_C_OS; // Lock que coordina al Cliente con el OyenteServidor
    private final Locks lock_conectado;
    private final ObjectOutputStream salida;
    private final ObjectInputStream entrada;
    private final ClienteVista vista;
    private final Entero conectado;
    private final Scanner scanner = new Scanner(System.in);
    private Boolean salir;
    private GestionListas gestionListas;

    public Cliente(String host, int puerto) throws IOException {
        this.socket = new Socket(host, puerto);
        this.salida = new ObjectOutputStream(socket.getOutputStream());
        this.salida.flush();
        this.entrada = new ObjectInputStream(socket.getInputStream());
        MonitorConsola ccout = new MonitorConsola(); // Consola concurrente implementada con un monitor
        this.vista = new ClienteVista(ccout);
        this.lock_C_OS = new LockRompeEmpate(PROCESOS_C_OS_PARALELO);
        this.salir = false;
        this.conectado = new Entero();
        this.lock_conectado = new BakeryLock(2);
    }

    public void iniciar() {
        try {
            // Pedimos los datos al cliente
            vista.pedir_nombre_usuario();
            String nombre = scanner.nextLine();
            Usuario datos_cliente = new Usuario(nombre);

            //Creamos el gestor de las listas
            gestionListas = new GestionListas(datos_cliente.getNombre(), vista);

            // Crear hilo del cliente que se encarga de recibir los mensajes del servidor
            Thread hiloOyenteServidor = new Thread(new OyenteServidor(this,socket, datos_cliente, vista, salida, entrada, conectado, lock_C_OS,lock_conectado, gestionListas));
            hiloOyenteServidor.start();

            //Comprobamos si se ha conseguido conectar con el servidor
            lock_conectado.takeLock(0);
            boolean usuario_valido = this.conectado.getNum() == 1;
            lock_conectado.releaseLock(0);

            // while hasta q el usuario sea válido
            while(!usuario_valido){
                // Enviar solicitud de conexión
                Mensaje mensaje = new MensajeConexion(datos_cliente.getNombre());
                salida.writeObject(mensaje);
                salida.flush();
                vista.solicitud_conexion_enviada();

                // Esperamos a que el hiloOyenteServidor reciba la confirmación de conexión o algún error y lo imprima en pantalla
                lock_C_OS.takeLock(0);


                // Si se ha establecido la conexion sale para no pedir el nombre otra vez
                lock_conectado.takeLock(0);
                if(conectado.getNum() == 1){ lock_conectado.releaseLock(0); break;}
                lock_conectado.releaseLock(0);

                // Soltamos el lock para que el OyenteServidor imprima lo que deba antes de pedir el nombre de usuario de nuevo
                lock_C_OS.releaseLock(0);

                // Pedimos los datos al cliente
                vista.pedir_nombre_usuario();
                nombre = scanner.nextLine();
                datos_cliente = new Usuario(nombre);


                lock_conectado.takeLock(0);
                usuario_valido = this.conectado.getNum() == 1;
                lock_conectado.releaseLock(0);
            }

            actualizarListasEnServidor();

            while (!salir) {
                vista.mostrarMenu();
                lock_C_OS.releaseLock(0);
                String opcion = scanner.nextLine();
                switch (opcion) {
                    case "1":
                        opcion_solicitarListas();
                        lock_C_OS.takeLock(0);
                        break;
                    case "2":
                        opcion_descargar();
                        lock_C_OS.takeLock(0);
                        break;
                    case "3":
                        opcion_ModificarListas();
                        break;
                    case "4":
                        opcion_salir();
                        lock_C_OS.takeLock(0);
                        break;
                    default:
                        if(!salir) {vista.opcion_invalida();}
                }
            }
            hiloOyenteServidor.join();
        } catch (SocketException e) {
            vista.error_socket_cerrado();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void opcion_salir() {
        salir = true;
        vista.conexion_cerrada();
        try {
            MensajeCerrarSesion cierre = new MensajeCerrarSesion();
            salida.writeObject(cierre);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void opcion_solicitarListas(){
        try {
            MensajeSolicitudLista solicitudLista = new MensajeSolicitudLista();
            salida.writeObject(solicitudLista);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        vista.lista_informacion_solicitada();
    }

    private void opcion_descargar(){
        vista.pedir_propietario_descarga();
        String propietario = scanner.nextLine();
        vista.pedir_nombre_archivo();
        String archivo = scanner.nextLine();
        try {
            MensajePedirProd pedirProd = new MensajePedirProd(archivo, propietario);
            salida.writeObject(pedirProd);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        vista.descarga_archivo_solicitada(archivo);
    }

    private void opcion_ModificarListas(){
        gestionListas.gestionarListas();
        actualizarListasEnServidor();
    }

    private void actualizarListasEnServidor(){
        List<String> info = gestionListas.listasCliente();//listas.listasCliente();
        MensajeInformacionCiente informacion = new MensajeInformacionCiente(info);
        try {
            salida.writeObject(informacion);
            salida.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        try {
            Cliente cliente = new Cliente(IP, PUERTO_SERVIDOR);
            cliente.iniciar();
        } catch (IOException e) {
            System.err.println("Error al conectar con el servidor: " + e.getMessage());
        }
    }

    public void cerrarConexion() { salir = true; System.out.println("Presione enter para salir.");}
}