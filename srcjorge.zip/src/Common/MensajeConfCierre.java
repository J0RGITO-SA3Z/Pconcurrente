package Common;

public class MensajeConfCierre extends Mensaje{
    public MensajeConfCierre() {
        super(TipoMensaje.CONFIRMACION_CIERRE);
    }
}
