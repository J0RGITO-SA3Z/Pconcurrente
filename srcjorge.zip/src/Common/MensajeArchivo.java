package Common;

import java.io.Serializable;

public class MensajeArchivo extends Mensaje {
    private byte[] contenido;
    private String nombre;
    private String propietario;

    public MensajeArchivo(byte[] contenido, String nombre, String propietario) {
        super(TipoMensaje.BYTES_CONTENIDO);
        this.contenido = contenido;
        this.nombre = nombre;
        this.propietario = propietario;
    }

    public byte[] getContenido() {
        return contenido;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPropietario() {
        return propietario;
    }
}