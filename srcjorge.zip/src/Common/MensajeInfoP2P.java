package Common;
//MensajePreparadorSCReceptor
public class MensajeInfoP2P extends Mensaje {
    private String ip;
    private int puerto;
    private String archivo;
    public MensajeInfoP2P(String ip, int puerto, String archivo){
        super(TipoMensaje.INFO_P2P);
        this.ip = ip;
        this.puerto = puerto;
        this.archivo = archivo;
    }

    public String getIp() {
        return ip;
    }

    public int getPuerto() {
        return puerto;
    }

    public String getArchivo() {
        return archivo;
    }
}
