package Common;

public class MensajeDescargar extends Mensaje {
    private String archivo;

    public MensajeDescargar(String archivo) {
        super(TipoMensaje.DESCARGAR_PRODUCTO);
        this.archivo = archivo;
    }

    public String getArchivo() {
        return archivo;
    }
}
