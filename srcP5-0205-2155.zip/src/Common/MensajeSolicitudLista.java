package Common;

public class MensajeSolicitudLista extends Mensaje {

    public MensajeSolicitudLista() {
        super(TipoMensaje.SOLICITUD_LISTA);
    }

}