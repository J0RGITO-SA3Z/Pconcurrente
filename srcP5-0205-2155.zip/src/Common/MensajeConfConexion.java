package Common;

import java.net.ServerSocket;

public class MensajeConfConexion extends Mensaje {

    private int puerto;

    public MensajeConfConexion(int puerto) {
        super(TipoMensaje.CONFIRMACION_CONEXION);
        this.puerto = puerto;
    }

    public int getPuerto() {
        return puerto;
    }

}
