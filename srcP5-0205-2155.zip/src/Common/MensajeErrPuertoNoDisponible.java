package Common;

public class MensajeErrPuertoNoDisponible extends Mensaje{
    public MensajeErrPuertoNoDisponible() {
        super(TipoMensaje.ERROR_PUERTO_P2P_NO_DISPONIBLE);
    }
}
