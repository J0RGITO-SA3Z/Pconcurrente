package Common;

import java.io.Serializable;

public class MensajeErrUsuarioExistente extends Mensaje {
    private TipoMensaje tipoError;

    public MensajeErrUsuarioExistente() {
        super(TipoMensaje.ERROR_USUARIO_EXISTENTE);
        this.tipoError = tipoError;
    }

    public TipoMensaje getTipoError() {
        return tipoError;
    }
}