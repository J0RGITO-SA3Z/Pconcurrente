package Common;

public class MensajeErrServidorLleno extends Mensaje {
    public MensajeErrServidorLleno() {
        super(TipoMensaje.ERROR_SERVIDOR_LLENO);
    }
}
