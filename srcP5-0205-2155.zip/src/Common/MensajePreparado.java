package Common;

public class MensajePreparado extends Mensaje {

    public MensajePreparado() {
        super(TipoMensaje.PREPARADO);
    }

}
