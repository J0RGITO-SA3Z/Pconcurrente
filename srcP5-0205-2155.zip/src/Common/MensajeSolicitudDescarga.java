package Common;

public class MensajeSolicitudDescarga extends Mensaje{
    private String propietario;
    private String nombreArchivo;
    public MensajeSolicitudDescarga(String nombreArchivo,String propietario) {
        super(TipoMensaje.SOLICITUD_DESCARGA);
        this.nombreArchivo = nombreArchivo;
        this.propietario = propietario;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getPropietario() {
        return propietario;
    }
}
