package Server;

import Common.*;
import Concurrent.*;
import View.ServidorVista;
import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.net.*;
import java.util.Stack;

public class OyenteCliente implements Runnable {
    private Socket socketCliente;
    private String nombre_cliente;
    private ServidorVista vista;
    private BufferPuertos buffer_puertos;
    private Map<String, Integer> usuarios; // Mapa compartido
    private Map<String, List<String>> informacion;
    private Stack<Integer> idsDisponibles;
    private Entero num_usuarios_conectados = new Entero();
    private Locks lock_map_usuarios;
    private Locks lock_map_informacion;
    private Locks lock_num_usuarios;
    private Locks lock_id;
    private int id_usuario;
    private int num_ids;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private boolean ejecutando;
    private int limite_usuarios;

    public OyenteCliente(Socket socketCliente, Map<String, Integer> usuarios, Map<String, List<String>> informacion, int num_ids, ServidorVista vista, Locks lock_map_usuarios,
                         Locks lock_num_usuarios, Locks lock_informacion, Locks lock_id, BufferPuertos buffer_puertos, Entero num_usuarios_conectados, Stack<Integer> idsDisponibles, int limite_usuarios) {
        try {
            salida = new ObjectOutputStream(socketCliente.getOutputStream());
            salida.flush();
            entrada = new ObjectInputStream(socketCliente.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.nombre_cliente = "";
        this.socketCliente = socketCliente;
        this.vista = vista;
        this.usuarios = usuarios;
        this.lock_map_usuarios = lock_map_usuarios;
        this.lock_num_usuarios = lock_num_usuarios;
        this.lock_map_informacion = lock_informacion;
        this.lock_id = lock_id;
        this.idsDisponibles = idsDisponibles;
        this.id_usuario = id_usuario;
        this.num_ids = num_ids;
        this.informacion = informacion;
        this.buffer_puertos = buffer_puertos;
        this.num_usuarios_conectados = num_usuarios_conectados;
        this.ejecutando = true;
        this.limite_usuarios = limite_usuarios;
    }

    private void cerrarRecursos() {
        try {
            if(!nombre_cliente.equals("")){
                lock_num_usuarios.takeLock(id_usuario);
                this.num_usuarios_conectados.decrement();
                lock_num_usuarios.releaseLock(id_usuario);
                lock_id.takeLock(0); // el 0 es para la interfaz pero no lo usa
                liberarId(id_usuario);
                lock_id.releaseLock(0);
                lock_map_informacion.takeLock(id_usuario);
                this.informacion.remove(nombre_cliente);
                lock_map_informacion.releaseLock(id_usuario);
            }

            ejecutando = false; // Detener el bucle

            if (entrada != null) entrada.close();
            if (salida != null) salida.close();
            if (socketCliente != null) socketCliente.close();
        } catch (IOException e) {
            vista.error_cerrar_recursos(e.getMessage());
        }
    }

    private void enviarListaInformacion(){
        lock_map_informacion.takeLock(id_usuario);
        Map<String, List<String>> copia = new HashMap<String, List<String>>(informacion);
        lock_map_informacion.releaseLock(id_usuario);
        MensajeLista mensajeLista = new MensajeLista(copia);
        try {
            salida.writeObject(mensajeLista);
            salida.flush();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Funcion que asigna un id a los nuevos usuarios
    public int asignarId() {
        if (!idsDisponibles.isEmpty()) {
            // Reutiliza un ID disponible del pool
            return idsDisponibles.pop();
        } else if (num_ids < limite_usuarios) {
            // Asigna un nuevo ID si no se ha alcanzado el límite
            return num_ids++;
        } else {
            throw new IllegalStateException("Límite máximo de usuarios alcanzado.");
        }
    }

    // Funcion que  libera los ids de los usuarios que se desconectan
    public void liberarId(int id) {
        if (id >= 0 && id < this.num_ids) {
            idsDisponibles.push(id); // Añade el ID al pool
            System.out.println("ID liberado: " + id);
        } else {
            throw new IllegalArgumentException("ID inválido: " + id);
        }
    }

    @Override
    public void run() {
        try {
            while (ejecutando) {
                // Leer mensaje del cliente
                Mensaje mensaje = (Mensaje) entrada.readObject();
                vista.mensajeRecibido(mensaje.getTipo().toString());
                int puerto_asignado;
                switch (mensaje.getTipo()) {
                    case CONEXION:
                        MensajeConexion conexion = (MensajeConexion) mensaje;

                        // Asignar un puerto al cliente
                        puerto_asignado = buffer_puertos.extraer();

                        // Si el servidor ha alcanzado el límite de usuarios no acepta más
                        lock_num_usuarios.takeLock(id_usuario);
                        boolean servidor_lleno = num_usuarios_conectados.getNum() >= limite_usuarios;
                        lock_num_usuarios.releaseLock(id_usuario);

                        if(servidor_lleno){
                            // Notificamos al cliente que el servidor está lleno
                            MensajeErrServidorLleno err = new MensajeErrServidorLleno();
                            salida.writeObject(err);
                            salida.flush();
                        }else{
                            // Asignamos un id al usuario
                            lock_id.takeLock(0); // este 0 es para q entre en la interfaz, pero no lo usa
                            id_usuario = asignarId();
                            lock_id.releaseLock(0);

                            // Incrementamos el numero de usuarios conectados
                            lock_num_usuarios.takeLock(id_usuario);
                            num_usuarios_conectados.increment();
                            lock_num_usuarios.releaseLock(id_usuario);

                            // Verificamos si el nombre de usuario ya estaba en uso
                            lock_map_usuarios.takeLock(id_usuario);
                            boolean usuario_valido = !this.usuarios.containsKey(conexion.getNombre());
                            if(usuario_valido){this.usuarios.put(conexion.getNombre(), puerto_asignado);}
                            lock_map_usuarios.releaseLock(id_usuario);

                            // Notificamos al cliente que se ha conectado exitosamente o que su usuario ya existe
                            if(usuario_valido){
                                vista.equipoConectado(nombre_cliente);
                                nombre_cliente = conexion.getNombre();
                                MensajeConfConexion confirmacion = new MensajeConfConexion(puerto_asignado);
                                salida.writeObject(confirmacion);
                                salida.flush();
                            } else{
                                MensajeErrUsuarioExistente err = new MensajeErrUsuarioExistente();
                                salida.writeObject(err);
                                salida.flush();
                            }
                        }
                        break;
                    case ERROR_PUERTO_P2P_NO_DISPONIBLE:

                        puerto_asignado = buffer_puertos.extraer();
                        mensaje = new MensajeAsignarNuevoPuerto(puerto_asignado);
                        salida.writeObject(mensaje);
                        salida.flush();

                        break;
                    case INFORMACION_CLIENTE:
                        MensajeInformacionCiente informacionCiente = (MensajeInformacionCiente) mensaje;
                        lock_map_informacion.takeLock(id_usuario);
                        informacion.put(nombre_cliente, informacionCiente.getDatos());
                        lock_map_informacion.releaseLock(id_usuario);
                        // Enviar lista de usuarios disponibles


                        break;
                    case SOLICITUD_LISTA:
                        MensajeSolicitudLista solicitudLista = (MensajeSolicitudLista) mensaje;
                        vista.listaInformacionSolicitada();
                        // Enviar lista de información
                        enviarListaInformacion();

                        break;
                    case SOLICITUD_DESCARGA:
                        MensajeSolicitudDescarga descarga = (MensajeSolicitudDescarga) mensaje;
                        // Obtener los datos del mensaje
                        String propietarioArchivo = descarga.getPropietario();
                        String nombreArchivo = descarga.getNombreArchivo();
                        // Verificar si el propietario existe en el mapa
                        if (!informacion.containsKey(propietarioArchivo)) {
                            vista.error_descarga();
                            break;
                        }
                        // Obtener la lista de archivos del propietario
                        List<String> archivosPropietario = informacion.get(propietarioArchivo);
                        // Verificar si el archivo solicitado existe en la lista del propietario
                        if (archivosPropietario == null || !archivosPropietario.contains(nombreArchivo)) {
                            vista.error_descarga(); //mandariamos excepción
                            break;
                        }



                        // Si tanto el usuario como el archivo existen, proceder con la descarga
                        vista.descarga_archivo_solicitada(nombreArchivo, propietarioArchivo);
                        // Enviar lista de usuarios disponibles


                        break;

                    case PREPARADO:
                        MensajePreparado preparado = (MensajePreparado) mensaje;
                        vista.usuario_preparado(nombre_cliente);
                        // Notificar al cliente receptor
                        break;

                    case CERRAR_SESION:
                        MensajeCerrarSesion cierre = (MensajeCerrarSesion) mensaje;

                        lock_map_usuarios.takeLock(id_usuario);
                        this.usuarios.remove(nombre_cliente);
                        lock_map_usuarios.releaseLock(id_usuario);

                        lock_num_usuarios.takeLock(id_usuario);
                        this.num_usuarios_conectados.decrement();
                        lock_num_usuarios.releaseLock(id_usuario);

                        lock_map_informacion.takeLock(id_usuario);
                        this.informacion.remove(nombre_cliente);
                        lock_map_informacion.releaseLock(id_usuario);

                        lock_id.takeLock(0); // el 0 es para la interfaz pero no lo usa
                        liberarId(id_usuario);
                        lock_id.releaseLock(0);


                        mensaje = new MensajeConfCierre();
                        salida.writeObject(mensaje);
                        salida.flush();
                        ejecutando = false;
                        vista.cierre_conexion(nombre_cliente);
                        break;

                    default:
                        vista.tipoMensajeDesconocido();
                }
            }
        } catch (EOFException | SocketException e) {
            vista.cliente_desconectado_abruptamente();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarRecursos(); // Cerrar recursos
        }
    }
}
