package Server;

import Common.MensajeConexion;
import Common.MensajeErrServidorLleno;
import Common.MensajeErrUsuarioExistente;
import Concurrent.ConcurrentConsole;
import Concurrent.*;
import View.ServidorVista;
import java.util.HashMap;
import java.io.*;
import java.net.*;
import java.util.*;

public class Servidor {
    protected final static int LIMITE_USUARIOS = 1;
    protected final static int PUERTO_SERVIDOR = 5000;
    protected final static int BUFFER_SOCKETS_CAPACITY = 5;
    private static Entero num_usuarios_conectados = new Entero();
    private static int num_ids = 0;
    private static BufferPuertos buffer_puertos;
    private static Map<String, Integer> usuarios_conectados = new HashMap<>();
    private static Map<String, List<String>> informacion = new HashMap<>();
    private static Locks lock_map_usuarios = new BakeryLock(LIMITE_USUARIOS);
    private static Locks lock_informacion = new BakeryLock(LIMITE_USUARIOS);
    private static Locks lock_num_usuarios = new LockTicket();
    private static Locks lock_id = new LockTicket(); // Solo puede ser LockTicket
    private static Stack<Integer> idsDisponibles = new Stack<>();

    public static void main(String[] args) throws IOException {
        // Creamos la consola y la vista para gestionar los mensajes de salida
        ConcurrentConsole ccout = new ConcurrentConsole();
        ServidorVista vista = new ServidorVista(ccout);
        vista.servidorIniciado();

        // Creamos el hilo encargado de escuchar activamente peticiones de conexión
        ServerSocket serverSocket = new ServerSocket(PUERTO_SERVIDOR);

        // Creamos el buffer que usamos para el productor-consumidor
        buffer_puertos = new BufferPuertos(BUFFER_SOCKETS_CAPACITY);

        // Creamos e iniciamos el productor
        Thread hiloProductor = new Thread(new Productor(0,buffer_puertos));
        hiloProductor.start();

        while (true) {
            // Acepta al usuario que quiera conectarse
            Socket socketCliente = serverSocket.accept();
            vista.nueva_conexion_cliente(socketCliente.getInetAddress());
            // Crear un nuevo hilo para manejar al cliente
            Thread hiloCliente = new Thread(new OyenteCliente(socketCliente, usuarios_conectados, informacion, num_ids,
                    vista, lock_map_usuarios, lock_num_usuarios, lock_informacion,lock_id, buffer_puertos, num_usuarios_conectados,
                    idsDisponibles, LIMITE_USUARIOS));
            hiloCliente.start();
        }
    }
}
