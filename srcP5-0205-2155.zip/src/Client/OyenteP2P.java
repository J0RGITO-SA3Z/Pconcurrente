// Client/OyenteP2P.java
package Client;

import Common.*;
import java.io.*;
import java.net.*;

public class OyenteP2P implements Runnable {

    private ServerSocket socketP2P;
    private Cliente cliente;

    public OyenteP2P(ServerSocket socketP2P, Cliente cliente) {
        this.socketP2P = socketP2P;
        this.cliente = cliente;
    }

    @Override
    public void run() {
        try {
            while (!Thread.interrupted()) {
                Socket conexionP2P = socketP2P.accept();
                new Thread(() -> {
                    try {
                        ObjectInputStream entrada = new ObjectInputStream(conexionP2P.getInputStream());
                        Mensaje mensaje = (Mensaje) entrada.readObject();
                        /*
                        if (mensaje instanceof MensajeSolicitudArchivo) {
                            MensajeSolicitudArchivo solicitud = (MensajeSolicitudArchivo) mensaje;
                            String nombreArchivo = solicitud.getNombreArchivo();
                            cliente.vista.descargando_archivo(nombreArchivo);
                            enviarArchivo(nombreArchivo, conexionP2P);
                        }
                        */
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }).start();
            }
        } catch (IOException e) {
            System.err.println("Error en el oyente P2P: " + e.getMessage());
        }
    }

    private void enviarArchivo(String nombreArchivo, Socket socket) {

    }

}