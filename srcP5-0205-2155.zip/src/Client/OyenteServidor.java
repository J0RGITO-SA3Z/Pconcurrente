package Client;

import Common.*;
import Concurrent.Entero;
import Concurrent.Locks;
import View.ClienteVista;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;


public class OyenteServidor implements Runnable {

    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private Usuario datos_cliente;
    private Socket socketCliente;
    private ClienteVista vista;
    private Entero conectado;
    private Locks lock_C_OS;
    private int puerto_P2P;
    private ServerSocket socketP2P;
    private volatile boolean ejecutando;


    public OyenteServidor(Socket socketCliente, Usuario datos, ClienteVista out, ObjectOutputStream salida, ObjectInputStream entrada, Entero conectado, Locks lock_C_OS) {
        try {
            this.salida = salida;
            salida.flush();
            this.entrada = entrada;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.lock_C_OS = lock_C_OS;
        this.datos_cliente = datos;
        this.socketCliente = socketCliente;
        this.vista = out;
        this.conectado = conectado;
        this.ejecutando = true;
    }

    @Override
    public void run() {
        try{
            Mensaje mensaje = null;
            while(ejecutando){
                lock_C_OS.takeLock(1);
                mensaje = (Mensaje) entrada.readObject();
                switch (mensaje.getTipo()) {
                    case CONFIRMACION_CONEXION:
                        MensajeConfConexion confirmacion = (MensajeConfConexion) mensaje;
                        // Leemos el puerto que nos ha asignado el servidor
                        puerto_P2P = confirmacion.getPuerto();

                        // Tratamos de crear un server socket con ese puerto
                        while (true) {
                            try {
                                socketP2P = new ServerSocket(puerto_P2P);
                                // Si llegamos aquí, el bind ha sido exitoso
                                System.out.println("ServerSocket P2P escuchando en el puerto " + puerto_P2P);
                                break;
                            } catch (BindException be) {
                                // El puerto ya está en uso
                                System.err.println("Puerto " + puerto_P2P + " no disponible. Por favor, elige otro.");
                                mensaje = new MensajeErrPuertoNoDisponible();
                                salida.writeObject(mensaje);
                                salida.flush();
                                mensaje = (Mensaje) entrada.readObject();
                                MensajeAsignarNuevoPuerto nuevoPuerto = (MensajeAsignarNuevoPuerto)mensaje;
                                puerto_P2P = nuevoPuerto.getPuerto();
                            } catch (Exception e) {
                                // Cualquier otro error al crear el socket
                                System.err.println("Error al crear ServerSocket en puerto " + puerto_P2P + ": " + e.getMessage());
                                puerto_P2P = confirmacion.getPuerto();
                            }
                        }

                        // Marcamos en una variable compartida con el cliente que nos hemos conectado
                        conectado.set(1);

                        // Confirmamos que se ha establecido la conexión con el servidor y que se ha creado el server socket en un puerto permitido
                        vista.conexion_exitosa();
                        break;
                    case ERROR_USUARIO_EXISTENTE:
                        vista.usuario_no_valido();
                        break;
                    case ERROR_SERVIDOR_LLENO:
                        vista.servidor_lleno();
                        break;
                    case LISTA_INFORMACION:
                        MensajeLista listaInformacion = (MensajeLista) mensaje;
                        vista.lista_informacion_recibida();
                        // Enviar lista de usuarios disponibles
                        vista.mostrar_lista_informacion(listaInformacion.getinformacion());
                        break;
                    case PREPARADO:
                        MensajePreparado preparado = (MensajePreparado) mensaje;
                        vista.equipo_preparado(datos_cliente.getNombre());
                        // Notificar al cliente receptor
                        break;

                    case CONFIRMACION_CIERRE:
                        detener();
                        break;

                    default:
                        vista.mensaje_desconocido();
                }
                lock_C_OS.releaseLock(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            //MANDAR MENSAJE DE DESCONEXION AL SERVIDOR
            cerrarRecursos();

        }
    }

    public void detener() {
        ejecutando = false; // Cambia la bandera para detener el hilo
    }

    private void cerrarRecursos() {
        try {
            if (socketCliente != null) socketCliente.close();
        } catch (IOException e) {
            vista.error_cerrar_recursos(e.getMessage());
        }
    }
}
