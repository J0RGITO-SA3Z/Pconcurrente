package Client;

import Common.*;
import Concurrent.Entero;
import Concurrent.Locks;
import View.ClienteVista;

import java.io.EOFException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;


public class OyenteServidor implements Runnable {

    private Cliente cliente;
    private GestionListas gestionListas;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private Usuario datos_cliente;
    private Socket socketCliente;
    private ClienteVista vista;
    private Entero conectado;
    private Locks lock_C_OS;
    private Locks lock_conectado;
    private int puerto_P2P;
    private ServerSocket socketP2P;
    private volatile boolean ejecutando;
    private Thread hiloServidorCliente;
    private ServidorP2P servidorP2P;


    public OyenteServidor(Cliente cliente, Socket socketCliente, Usuario datos, ClienteVista out, ObjectOutputStream salida, ObjectInputStream entrada,
                          Entero conectado, Locks lock_C_OS, Locks lock_conectado , GestionListas gestionListas) {
        try {
            this.salida = salida;
            salida.flush();
            this.entrada = entrada;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.cliente = cliente;
        this.lock_C_OS = lock_C_OS;
        this.lock_conectado = lock_conectado;
        this.datos_cliente = datos;
        this.socketCliente = socketCliente;
        this.vista = out;
        this.conectado = conectado;
        this.gestionListas = gestionListas;
        this.ejecutando = true;
    }

    @Override
    public void run() {
        try{
            Mensaje mensaje = null;
            while(ejecutando){
                lock_C_OS.takeLock(1);
                mensaje = (Mensaje) entrada.readObject();
                switch (mensaje.getTipo()) {
                    case CONFIRMACION_CONEXION:
                        MensajeConfConexion confirmacion = (MensajeConfConexion) mensaje;
                        gestionarConfirmacionConexion(confirmacion);
                        break;
                    case ERROR_USUARIO_EXISTENTE:
                        vista.usuario_no_valido();
                        break;
                    case ERROR_SERVIDOR_LLENO:
                        vista.servidor_lleno();
                        break;
                    case LISTA_INFORMACION:
                        MensajeLista listaInformacion = (MensajeLista) mensaje;
                        vista.lista_informacion_recibida();
                        vista.mostrar_lista_informacion(listaInformacion.getinformacion());
                        break;
                    case INFO_P2P:
                        MensajeInfoP2P infoP2P = (MensajeInfoP2P) mensaje;
                        gestionarInfoP2P(infoP2P);
                        break;
                    case ERROR_PROPIETARIO_NO_EXISTENTE:
                        vista.error_propietario_no_existente();
                        break;
                    case ERROR_ARCHIVO_SOLICITADO_INVALIDO:
                        vista.error_archivo_solicitado_invalido();
                        break;
                    case CONFIRMACION_CIERRE:
                        detener();
                        break;
                    default:
                        vista.mensaje_desconocido();
                }
                lock_C_OS.releaseLock(1);
            }
        } catch(SocketException | EOFException e) {
            vista.error_socket_cerrado();
            cliente.cerrarConexion();
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            //MANDAR MENSAJE DE DESCONEXION AL SERVIDOR
            cerrarRecursos();
        }
    }

    private void gestionarInfoP2P(MensajeInfoP2P infoP2P) throws IOException {
        // Quitamos la barra de la IP si la hay
        String ip = infoP2P.getIp().replace("/", "");

        //Creamos un socket y una entrada/salida para conectarnos con el servidor P2P
        Socket socketServerP2P = new Socket(ip, infoP2P.getPuerto());
        ObjectOutputStream salidaServerP2P = new ObjectOutputStream(socketServerP2P.getOutputStream());
        salidaServerP2P.flush();
        ObjectInputStream entradaServerP2P = new ObjectInputStream(socketServerP2P.getInputStream());
        
        Thread hiloSolicitanteP2P = new Thread(new SolicitanteP2P(socketServerP2P,salidaServerP2P,entradaServerP2P, infoP2P.getArchivo()));
        hiloSolicitanteP2P.start();
    }

    private void gestionarConfirmacionConexion(MensajeConfConexion confirmacion) {
        try {
            // Cuando llegamos aqui el servidor ha aceptado nuestro nombre de usuario
            datos_cliente = new Usuario(confirmacion.getNombreUsuario());
            gestionListas.setNombre(confirmacion.getNombreUsuario());

            // Leemos el puerto que nos ha asignado el servidor
            puerto_P2P = confirmacion.getPuerto();

            // Tratamos de crear un server socket con ese puerto
            while (true) {
                try {
                    socketP2P = new ServerSocket(puerto_P2P);
                    // Si llegamos aquí, el bind ha sido exitoso

                    servidorP2P = new ServidorP2P(socketP2P, gestionListas, datos_cliente.getNombre());
                    this.hiloServidorCliente = new Thread(servidorP2P);
                    hiloServidorCliente.start();

                    System.out.println("ServerSocket P2P escuchando en el puerto " + puerto_P2P);
                    break;
                } catch (BindException be) {
                    // El puerto ya está en uso
                    System.err.println("Puerto " + puerto_P2P + " no disponible. Por favor, elige otro.");
                    Mensaje mensaje = new MensajeErrPuertoNoDisponible();
                    salida.writeObject(mensaje);
                    salida.flush();
                    mensaje = (Mensaje) entrada.readObject();
                    MensajeAsignarNuevoPuerto nuevoPuerto = (MensajeAsignarNuevoPuerto)mensaje;
                    puerto_P2P = nuevoPuerto.getPuerto();
                } catch (Exception e) {
                    // Cualquier otro error al crear el socket
                    System.err.println("Error al crear ServerSocket en puerto " + puerto_P2P + ": " + e.getMessage());
                    puerto_P2P = confirmacion.getPuerto();
                }
            }


            // Marcamos en una variable compartida con el cliente que nos hemos conectado
            lock_conectado.takeLock(1);
            conectado.set(1);
            lock_conectado.releaseLock(1);

            // Confirmamos que se ha establecido la conexión con el servidor y que se ha creado el server socket en un puerto permitido
            vista.conexion_exitosa();
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void detener() {
        ejecutando = false; // Cambia la bandera para detener el hilo
    }

    private void cerrarRecursos() {
        try {
            if (socketCliente != null) socketCliente.close();
            this.servidorP2P.detener();
            hiloServidorCliente.join();
        } catch (IOException e) {
            vista.error_cerrar_recursos(e.getMessage());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
