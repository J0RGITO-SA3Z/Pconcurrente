package Client;

import Common.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ProveedorP2P implements Runnable {

    private Socket socketSolicitante;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private GestionListas gestionListas;
    private String nombreUsuario;
    private boolean ejecutando = true;

    public ProveedorP2P(Socket socketSolicitante, GestionListas gestionListas, String nombreUsuario) {
        this.socketSolicitante = socketSolicitante;
        try {
            salida = new ObjectOutputStream(socketSolicitante.getOutputStream());
            salida.flush();
            entrada = new ObjectInputStream(socketSolicitante.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.gestionListas = gestionListas;
        this.nombreUsuario = nombreUsuario;
    }
    @Override
    public void run() {
        try {
            while(ejecutando){
                Mensaje mensaje = (Mensaje) entrada.readObject();
                switch (mensaje.getTipo()) {
                    case PEDIR_PRODUCTO:
                        // Si tuviera que hacer alguna comprobacion o preparar algo antes de mandar el mensaje lo haria aqui
                        // En nuestro caso, como nuestra implementacion supone que el servidorP2P de cada cliente esta abierto siempre,
                        // no hay que hacer nada.
                        Mensaje preparado = new MensajePreparado();
                        salida.writeObject(preparado);
                        salida.flush();
                        //Una vez mas, debdo a nuestra implementacion, no hay que hacer nada mas, asi que salimos del bucle
                        ejecutando = false;
                        break;
                    case CONEXION:
                        Mensaje confirmacion = new MensajeConfConexion();
                        salida.writeObject(confirmacion);
                        salida.flush();
                        break;

                    case DESCARGAR_PRODUCTO:
                        MensajeDescargar descarga = (MensajeDescargar)mensaje;
                        // Leemos el archivo como bytes de la ruta ./usuarios/nombreUsuario/nombreArchivo.txt
                        byte[] contenido =  this.gestionListas.leerArchivoComoBytes("usuarios/" + nombreUsuario + "/" + descarga.getArchivo());
                        MensajeArchivo mensajeArchivo = new MensajeArchivo(contenido, nombreUsuario, descarga.getArchivo());
                        salida.writeObject(mensajeArchivo);
                        salida.flush();
                        ejecutando = false;
                        break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
        }
    }
}