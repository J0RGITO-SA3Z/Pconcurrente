package Client;

import Common.Mensaje;
import Common.MensajeArchivo;
import Common.MensajeConexion;
import Common.MensajeDescargar;

import java.io.*;
import java.net.Socket;

public class SolicitanteP2P implements Runnable {
    private Socket socketServerP2P;
    private ObjectOutputStream salidaServerP2P;
    private ObjectInputStream entradaServerP2P;
    private boolean ejecutando = true;
    private String archivo;

    public SolicitanteP2P(Socket socketServerP2P, ObjectOutputStream salidaServerP2P, ObjectInputStream entradaServerP2P, String archivo) {
        this.socketServerP2P = socketServerP2P;
        this.salidaServerP2P = salidaServerP2P;
        this.entradaServerP2P = entradaServerP2P;
        this.archivo = archivo;
    }

    @Override
    public void run() {
        try {
            // Vamos a reutilizar el mensaje de conexion a pesar de que tiene de atributo nombre
            Mensaje conexion = new MensajeConexion();
            salidaServerP2P.writeObject(conexion);
            salidaServerP2P.flush();
            while(ejecutando){
                Mensaje mensaje = (Mensaje) entradaServerP2P.readObject();
                switch (mensaje.getTipo()) {
                    case CONFIRMACION_CONEXION:
                        Mensaje pedirDescarga = new MensajeDescargar(archivo);
                        salidaServerP2P.writeObject(pedirDescarga);
                        salidaServerP2P.flush();
                        break;
                    case BYTES_CONTENIDO:
                        MensajeArchivo archivo = (MensajeArchivo) mensaje;
                        byte[] contenido = archivo.getContenido();
                        // Sacamos la ruta de la carpeta de descargas
                        String rutaDescargas = System.getProperty("user.home") + File.separator + "Downloads";
                        // Creamos una referencia a la carpeta Descargas y la creamos si no existe
                        File carpetaDescargas = new File(rutaDescargas);
                        if (!carpetaDescargas.exists()) {
                            carpetaDescargas.mkdirs(); // Esto normalmente no hace falta, ya existe
                        }
                        // Nombre del archivo (con el nombre de archivo y el propietario originales)
                        String nombreArchivo = archivo.getNombre() + " - " + archivo.getPropietario();  // O mejor, recíbelo como parte del MensajeArchivo
                        File archivoDestino = new File(carpetaDescargas, nombreArchivo);
                        // Escribir el archivo en Descargas
                        try (FileOutputStream fos = new FileOutputStream(archivoDestino)) {
                            fos.write(contenido);
                            System.out.println("Archivo descargado en tu carpeta Descargas: " + archivoDestino.getAbsolutePath());
                        } catch (IOException e) {
                            System.err.println("Error al guardar el archivo en Descargas.");
                            e.printStackTrace();
                        }
                        ejecutando = false;
                        break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}
