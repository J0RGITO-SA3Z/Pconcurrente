package Client;

import View.ClienteVista;

import java.io.*;
import java.util.*;

public class GestionListas {

    private ClienteVista vista;
    private String rutaUsuario;
    private final Scanner scanner = new Scanner(System.in);

    public GestionListas(String nombreUsuario, ClienteVista vista) {
        this.vista = vista;
        this.rutaUsuario = "usuarios/" + nombreUsuario + "/";
        File directorio = new File(rutaUsuario);
        if (!directorio.exists()) {
            directorio.mkdirs(); // Crear el directorio si no existe
        }
    }

    public List<String> listasCliente() {
        File directorio = new File(rutaUsuario);
        File[] archivos = directorio.listFiles((dir, name) -> name.endsWith(".txt"));

        List<String> nombresListas = new ArrayList<>();
        if (archivos != null && archivos.length > 0) {
            for (File archivo : archivos) {
                nombresListas.add(archivo.getName()); // Agregar el nombre del archivo a la lista
            }
        }

        return nombresListas; // Devuelve la lista serializable
    }

    public void gestionarListas() {
        System.out.println("GESTIONANDO LISTAS...");
        File directorio = new File(rutaUsuario);
        File[] archivos = directorio.listFiles((dir, name) -> name.endsWith(".txt"));

        if (archivos == null || archivos.length == 0) {
            System.out.println("No tienes listas disponibles.");
        } else {
            // Mostrar las listas disponibles
            System.out.println("Tus listas disponibles:");
            for (int i = 0; i < archivos.length; i++) {
                System.out.println((i + 1) + ". " + archivos[i].getName());
            }
        }

        // Menú principal
        System.out.print("¿Qué deseas hacer? (1: Ver lista, 2: Crear lista, 3: Modificar lista, 4: Eliminar lista, 0: Cancelar): ");
        String opcion = scanner.nextLine();

        switch (opcion) {
            case "0":
                System.out.println("Acción cancelada.");
                break;
            case "1": // Ver contenido de la lista
                verContenidoLista(archivos);
                break;
            case "2": // Crear una nueva lista
                crearNuevaLista();
                break;
            case "3": // Modificar una lista existente
                modificarListaExistente(archivos);
                break;
            case "4": // Eliminar una lista
                eliminarLista(archivos);
                break;
            default:
                System.out.println("Acción inválida.");
        }
    }

    private void verContenidoLista(File[] archivos) {
        System.out.print("Selecciona el número de la lista que deseas ver (-1 para cancelar): ");
        int opcion = pedirNum(archivos);

        if(opcion == -1) {
            System.out.println("Acción cancelada.");
            return;
        }

        File archivoSeleccionado = archivos[opcion - 1];
        System.out.println("Mostrando contenido de la lista: " + archivoSeleccionado.getName());

        try (BufferedReader br = new BufferedReader(new FileReader(archivoSeleccionado))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    private void crearNuevaLista() {
        System.out.print("Introduce el nombre de la nueva lista (sin espacios ni caracteres especiales): ");
        String nombreLista = scanner.nextLine().trim();
        if (nombreLista.isEmpty()) {
            System.out.println("El nombre de la lista no puede estar vacío.");
            return;
        }

        File nuevaLista = new File(rutaUsuario + nombreLista + ".txt");
        if (nuevaLista.exists()) {
            System.out.println("Ya existe una lista con ese nombre.");
            return;
        }

        try {
            if (nuevaLista.createNewFile()) {
                System.out.println("Lista creada exitosamente: " + nuevaLista.getName());
            } else {
                System.out.println("Error al crear la lista.");
            }
        } catch (IOException e) {
            System.out.println("Error al crear el archivo: " + e.getMessage());
        }
    }

    private void modificarListaExistente(File[] archivos) {
        System.out.print("Selecciona el número de la lista que deseas modificar (-1 para cancelar): ");
        int opcion = pedirNum(archivos);

        if(opcion == -1) {
            System.out.println("Acción cancelada.");
            return;
        }

        File archivoSeleccionado = archivos[opcion - 1];
        System.out.println("Modificando la lista: " + archivoSeleccionado.getName());

        // Leer el contenido actual de la lista
        StringBuilder contenido = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(archivoSeleccionado))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                contenido.append(linea).append("\n");
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
            return;
        }

        // Mostrar el contenido actual y permitir editarlo
        System.out.println("Contenido actual de la lista:");
        System.out.println(contenido.toString());
        System.out.println("Introduce el nuevo contenido de la lista (escribe 'FIN' en una línea nueva para terminar):");

        // Leer el nuevo contenido
        StringBuilder nuevoContenido = new StringBuilder();
        String linea;
        while (!(linea = scanner.nextLine()).equalsIgnoreCase("FIN")) {
            nuevoContenido.append(linea).append("\n");
        }

        // Sobrescribir el archivo con el nuevo contenido
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoSeleccionado))) {
            bw.write(nuevoContenido.toString());
            System.out.println("Lista modificada exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    private void eliminarLista(File[] archivos) {
        System.out.print("Selecciona el número de la lista que deseas eliminar (-1 para cancelar): ");
        int opcion = pedirNum(archivos);

        if(opcion == -1) {
            System.out.println("Acción cancelada.");
            return;
        }

        if (opcion > 0 && opcion <= archivos.length) {
            File archivoSeleccionado = archivos[opcion - 1];
            if (archivoSeleccionado.delete()) {
                System.out.println("Lista eliminada: " + archivoSeleccionado.getName());
            } else {
                System.out.println("Error al eliminar la lista.");
            }
        } else {
            System.out.println("Opción inválida.");
        }
    }

    public File obtenerArchivo(String nombreLista) {
        return new File(rutaUsuario + nombreLista);
    }

    public byte[] leerArchivoComoBytes(String ruta) throws IOException {
        File file = new File(ruta);
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        fis.read(buffer);
        fis.close();
        return buffer;
    }

    public void setNombre(String nombreUsuario) {
        this.rutaUsuario = "usuarios/" + nombreUsuario + "/";
    }

    private int pedirNum(File[] archivos) {
        int opcion = -1;
        while (archivos.length >= 1) {
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                if (opcion == - 1 || opcion > 0 && opcion <= archivos.length) {
                    break;
                } else {
                    System.out.print("Opción inválida. Introduce un número entre 1 y " + archivos.length + ": ");
                }
            } else {
                System.out.print("Entrada no válida. Por favor, introduce un número: ");
                scanner.next(); // Limpiamos la entrada incorrecta
            }
        }
        return opcion;
    }
}