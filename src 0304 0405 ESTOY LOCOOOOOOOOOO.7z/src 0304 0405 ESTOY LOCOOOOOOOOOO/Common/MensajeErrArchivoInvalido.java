package Common;

public class MensajeErrArchivoInvalido extends Mensaje {
    public MensajeErrArchivoInvalido() {
        super(TipoMensaje.ERROR_ARCHIVO_SOLICITADO_INVALIDO);
    }
}
