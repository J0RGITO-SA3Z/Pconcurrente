package Common;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class MensajeInformacionCiente extends Mensaje{

    private List<String> datos;
    public MensajeInformacionCiente(List<String> datos) {
        super(TipoMensaje.ACTUALIZAR_INFORMACION_CLIENTE);
        this.datos = datos;
    }

    public List<String> getDatos() {
        return datos;
    }

}
