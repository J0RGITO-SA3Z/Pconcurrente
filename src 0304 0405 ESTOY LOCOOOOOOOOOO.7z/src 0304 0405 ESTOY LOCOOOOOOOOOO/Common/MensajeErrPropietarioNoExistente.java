package Common;

public class MensajeErrPropietarioNoExistente extends Mensaje {
    public MensajeErrPropietarioNoExistente(){
        super(TipoMensaje.ERROR_PROPIETARIO_NO_EXISTENTE);
    }
}
