package Common;

public class MensajeCerrarSesion extends Mensaje{

    public MensajeCerrarSesion() {
        super(TipoMensaje.CERRAR_SESION);
    }

}
