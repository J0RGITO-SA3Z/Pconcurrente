package Common;

public class MensajePedirProd extends Mensaje{
    private String propietario;
    private String nombreArchivo;
    public MensajePedirProd(String nombreArchivo, String propietario) {
        super(TipoMensaje.PEDIR_PRODUCTO);
        this.nombreArchivo = nombreArchivo;
        this.propietario = propietario;
    }

    public MensajePedirProd() {
        super(TipoMensaje.PEDIR_PRODUCTO);
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getPropietario() {
        return propietario;
    }
}
