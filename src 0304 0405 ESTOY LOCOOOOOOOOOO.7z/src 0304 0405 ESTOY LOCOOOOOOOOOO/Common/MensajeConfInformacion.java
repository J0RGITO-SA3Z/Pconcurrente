package Common;

public class MensajeConfInformacion extends Mensaje{
    public MensajeConfInformacion() {
        super(TipoMensaje.CONFIRMACION_INFORMACION);
    }
}
