package Common;

import java.net.ServerSocket;

public class MensajeConfConexion extends Mensaje {

    private int puerto;
    private String nombre_usuario;

    public MensajeConfConexion(int puerto, String nombre_usuario) {
        super(TipoMensaje.CONFIRMACION_CONEXION);
        this.puerto = puerto;
        this.nombre_usuario = nombre_usuario;
    }

    public MensajeConfConexion() {
        super(TipoMensaje.CONFIRMACION_CONEXION);
    }

    public int getPuerto() {
        return puerto;
    }

    public String getNombreUsuario() {
        return nombre_usuario;
    }

}
